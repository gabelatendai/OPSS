<?php

namespace Nexmo\Account;

class VoicePrice extends Price
{
    protected $priceMethod = 'getOutboundVoicePrice';
}
