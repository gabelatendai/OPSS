<footer id="footer">
	<div class="container">
		<div class="row">
			<div class="col-sm-3 col-md-4">
				<div class="widget">
					<div class="widget-content">
						<img class="logo" src="images/logo.png" alt="" height="40px" width="40px">
						<p>Kushinga Phikelela Polytechnic provides easy access to Internship and Applicants</p></div>
				</div>
			</div>

			<div class="col-sm-3 col-md-4">
				<div class="widget">
					<h6 class="widget-title">Navigation</h6>

					<div class="widget-content">
						<div class="row">
							<div class="col-xs-6 col-sm-12 col-md-6">
								<ul class="footer-links">
									<li><a href="#">Home</a></li>
									<li><a href="#">Jobs</a></li>
									<li><a href="#">Candidates</a></li>
									<li><a href="#">Partners</a></li>
								</ul>
							</div>

							<div class="col-xs-6 col-sm-12 col-md-6">
								<ul class="footer-links">
									<li><a href="#">About Us</a></li>
									<li><a href="#">Contact Us</a></li>
									<li><a href="#">Terms &amp; Conditions</a></li>
									<li><a href="#">Privacy Policy</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-sm-3 col-md-2">
				<div class="widget">
					<h6 class="widget-title">Follow Us</h6>

					<div class="widget-content">
						<ul class="footer-links">
							<li><a href="#">Blog</a></li>
							<li><a href="#">Twitter</a></li>
							<li><a href="#">Facebook</a></li>
							<li><a href="#">Youtube</a></li>
						</ul>
					</div>
				</div>
			</div>

			<div class="col-sm-3 col-md-2">
				<div class="widget">
					<h6 class="widget-title">Popular Jobs</h6>

					<div class="widget-content">
						<ul class="footer-links">
							<li><a href="#">Web Developer</a></li>
							<li><a href="#">Web Designer</a></li>
							<li><a href="#">UX Engineer</a></li>
							<li><a href="#">Account Manager</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="copyright">
		<div class="container">
			<p>Copyright &copy;<script>document.write(new Date().getFullYear());</script>Developed by Pedzisai Jani</p>

			<ul class="footer-social">
				<li><a href="#" class="fa fa-facebook"></a></li>
				<li><a href="#" class="fa fa-twitter"></a></li>
				<li><a href="#" class="fa fa-linkedin"></a></li>
				<li><a href="#" class="fa fa-google-plus"></a></li>
				<li><a href="#" class="fa fa-pinterest"></a></li>
				<li><a href="#" class="fa fa-dribbble"></a></li>
			</ul>
		</div>
	</div>
</footer> <!-- end #footer -->

</div> <!-- end #main-wrapper -->

<!-- Scripts -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="careershtml-updated/js/jquery-1.11.0.min.js"><\/script>')</script>
<script src="http://maps.google.com/maps/api/js?sensor=false&libraries=geometry&v=3.7"></script>
<script src="careershtml-updated/js/maplace.min.js"></script>
<script src="careershtml-updated/js/jquery.ba-outside-events.min.js"></script>
<script src="careershtml-updated/js/jquery.responsive-tabs.js"></script>
<script src="careershtml-updated/js/jquery.flexslider-min.js"></script>
<script src="careershtml-updated/js/jquery.fitvids.js"></script>
<script src="careershtml-updated/js/jquery-ui-1.10.4.custom.min.js"></script>
<script src="careershtml-updated/js/jquery.inview.min.js"></script>
<script src="careershtml-updated/js/script.js"></script>
</body>
</html>